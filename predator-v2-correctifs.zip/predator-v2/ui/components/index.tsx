// ui/components/EquityCurve.tsx
"use client";
import { useEffect, useRef } from "react";

interface Point { timestamp: string; balance: number; drawdown: number; }

export default function EquityCurve({ data }: { data: Point[] }) {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas || !data.length) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const W = canvas.width  = canvas.offsetWidth  * window.devicePixelRatio;
    const H = canvas.height = canvas.offsetHeight * window.devicePixelRatio;
    ctx.scale(window.devicePixelRatio, window.devicePixelRatio);
    const w = canvas.offsetWidth;
    const h = canvas.offsetHeight;

    const balances = data.map((d) => d.balance);
    const min = Math.min(...balances) * 0.98;
    const max = Math.max(...balances) * 1.02;
    const PAD = { t: 16, r: 16, b: 24, l: 56 };

    ctx.clearRect(0, 0, w, h);

    // Grid
    ctx.strokeStyle = "rgba(255,255,255,0.04)";
    ctx.lineWidth = 1;
    for (let i = 0; i <= 4; i++) {
      const y = PAD.t + (h - PAD.t - PAD.b) * (i / 4);
      ctx.beginPath(); ctx.moveTo(PAD.l, y); ctx.lineTo(w - PAD.r, y); ctx.stroke();
      const val = max - (max - min) * (i / 4);
      ctx.fillStyle = "rgba(255,255,255,0.3)";
      ctx.font = "10px monospace";
      ctx.fillText(`${Math.round(val).toLocaleString()}€`, 0, y + 4);
    }

    const px = (i: number) => PAD.l + ((w - PAD.l - PAD.r) * i) / (data.length - 1);
    const py = (v: number) => PAD.t + (h - PAD.t - PAD.b) * (1 - (v - min) / (max - min));

    // Baseline 10k
    const baseY = py(10_000);
    ctx.strokeStyle = "rgba(255,255,255,0.08)";
    ctx.setLineDash([4, 4]);
    ctx.beginPath(); ctx.moveTo(PAD.l, baseY); ctx.lineTo(w - PAD.r, baseY); ctx.stroke();
    ctx.setLineDash([]);

    // Gradient fill
    const grad = ctx.createLinearGradient(0, PAD.t, 0, h - PAD.b);
    grad.addColorStop(0, "rgba(16,185,129,0.2)");
    grad.addColorStop(1, "rgba(16,185,129,0)");

    ctx.beginPath();
    ctx.moveTo(px(0), h - PAD.b);
    data.forEach((d, i) => ctx.lineTo(px(i), py(d.balance)));
    ctx.lineTo(px(data.length - 1), h - PAD.b);
    ctx.closePath();
    ctx.fillStyle = grad;
    ctx.fill();

    // Line
    ctx.strokeStyle = "#10b981";
    ctx.lineWidth = 2;
    ctx.lineJoin = "round";
    ctx.beginPath();
    data.forEach((d, i) => i === 0 ? ctx.moveTo(px(i), py(d.balance)) : ctx.lineTo(px(i), py(d.balance)));
    ctx.stroke();
  }, [data]);

  return data.length === 0
    ? <div className="h-48 flex items-center justify-center text-gray-600 text-sm">En attente de données...</div>
    : <canvas ref={ref} style={{ width: "100%", height: "240px", display: "block" }} />;
}


// ── MonthlyChart ──────────────────────────────────────────────────
// ui/components/MonthlyChart.tsx
export function MonthlyChart({ data }: { data: any[] }) {
  if (!data.length) return (
    <div className="h-32 flex items-center justify-center text-gray-600 text-sm">
      Pas encore de données mensuelles.
    </div>
  );
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b border-gray-800">
            {["Mois","Paris","Gagnés","Win %","Profit","CLV Réel"].map(h =>
              <th key={h} className="text-left px-3 py-2 text-xs text-gray-500 uppercase tracking-wider">{h}</th>
            )}
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-800/40">
          {data.map((row, i) => (
            <tr key={i} className="hover:bg-gray-900/30">
              <td className="px-3 py-2 font-mono text-xs">{new Date(row.month).toLocaleDateString("fr-FR", { month: "long", year: "numeric" })}</td>
              <td className="px-3 py-2 text-center">{row.bets}</td>
              <td className="px-3 py-2 text-center text-emerald-400">{row.wins}</td>
              <td className={`px-3 py-2 text-center font-bold ${row.win_rate_pct >= 60 ? "text-emerald-400" : "text-yellow-400"}`}>{row.win_rate_pct}%</td>
              <td className={`px-3 py-2 font-mono font-bold ${row.profit_eur >= 0 ? "text-emerald-400" : "text-red-400"}`}>{row.profit_eur >= 0 ? "+" : ""}{row.profit_eur.toFixed(0)}€</td>
              <td className="px-3 py-2 text-blue-400 font-mono">{row.avg_clv_real_pct?.toFixed(2)}%</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}


// ── CountdownTimer ────────────────────────────────────────────────
// ui/components/CountdownTimer.tsx
"use client";
import { useEffect, useState } from "react";

export default function CountdownTimer() {
  const [remain, setRemain] = useState("");

  useEffect(() => {
    const tick = () => {
      const now = new Date();
      const h = now.getUTCHours();
      const nextHour = h < 8 ? 8 : h < 16 ? 16 : 24;
      const next = new Date(now);
      next.setUTCHours(nextHour % 24, 0, 0, 0);
      if (nextHour === 24) next.setUTCDate(next.getUTCDate() + 1);
      const diff = next.getTime() - now.getTime();
      const hh = Math.floor(diff / 3_600_000);
      const mm = Math.floor((diff % 3_600_000) / 60_000);
      const ss = Math.floor((diff % 60_000) / 1_000);
      setRemain(`${String(hh).padStart(2,"0")}:${String(mm).padStart(2,"0")}:${String(ss).padStart(2,"0")}`);
    };
    tick();
    const iv = setInterval(tick, 1000);
    return () => clearInterval(iv);
  }, []);

  const sessions = [
    { name: "Asie",   hour: 0  },
    { name: "Europe", hour: 8  },
    { name: "USA",    hour: 16 },
  ];

  return (
    <div>
      <p className="font-mono text-4xl font-bold text-emerald-400 tabular-nums">{remain}</p>
      <div className="flex gap-3 mt-3">
        {sessions.map(s => {
          const now = new Date();
          const h = now.getUTCHours();
          const active = (s.hour <= h && h < s.hour + 8) || (s.hour === 0 && h >= 16);
          return (
            <span key={s.name} className={`px-2 py-0.5 rounded text-xs border ${
              active ? "border-emerald-700 text-emerald-400 bg-emerald-950" : "border-gray-800 text-gray-600"
            }`}>{s.name}</span>
          );
        })}
      </div>
    </div>
  );
}


// ── StatusBadge ───────────────────────────────────────────────────
export function StatusBadge({ scanning }: { scanning: boolean }) {
  return (
    <div className={`flex items-center gap-2 px-4 py-2 rounded-full border text-sm font-medium ${
      scanning
        ? "bg-amber-950 border-amber-700 text-amber-300"
        : "bg-emerald-950 border-emerald-700 text-emerald-300"
    }`}>
      <span className={`w-2 h-2 rounded-full ${scanning ? "bg-amber-400 animate-ping" : "bg-emerald-400"}`} />
      {scanning ? "Scanning..." : "Online"}
    </div>
  );
}


// ── ScanLogTable ──────────────────────────────────────────────────
export function ScanLogTable({ logs }: { logs: any[] }) {
  if (!logs.length) return (
    <p className="text-sm text-gray-600 text-center py-6">Aucun scan enregistré.</p>
  );
  return (
    <table className="w-full text-sm">
      <thead>
        <tr className="border-b border-gray-800">
          {["Session","Events","Signaux","Durée","Heure"].map(h =>
            <th key={h} className="text-left px-3 py-2 text-xs text-gray-500 uppercase tracking-wider">{h}</th>
          )}
        </tr>
      </thead>
      <tbody className="divide-y divide-gray-800/30">
        {logs.map((log, i) => (
          <tr key={i} className="hover:bg-gray-800/20">
            <td className="px-3 py-2 font-medium">{log.session_name}</td>
            <td className="px-3 py-2 text-gray-400">{log.events_analyzed}</td>
            <td className="px-3 py-2 text-emerald-400 font-bold">{log.signals_validated}</td>
            <td className="px-3 py-2 font-mono text-xs text-gray-400">{log.duration_seconds?.toFixed(1)}s</td>
            <td className="px-3 py-2 text-xs text-gray-500 font-mono">
              {new Date(log.scanned_at).toLocaleString("fr-FR", { day:"2-digit", month:"2-digit", hour:"2-digit", minute:"2-digit" })}
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}
