# tgbot package — réexporte depuis core.notifications
